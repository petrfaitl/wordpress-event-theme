=== Love It ===
Plugin Name: Love It (Maintained by Vamtam)
Plugin URI: http://vamtam.com
Description: Adds a "Love It" link to posts, pages, and custom post types
Version: 1.0.3
Author: Vamtam, Pippin Williamson
Author URI: http://vamtam.com

Love It is a simple plugin that adds a "Love It" link to your posts, pages, and custom post types. Show your most popular items in a widget.

== Description ==

Love It is a simple plugin that adds a "Love It" link to your posts, pages, and custom post types. It works similar to Facebook's Like button, but is exclusive to your website. It provides a great way for users to show their appreciation, and for you to gain a good idea of which posts are your most popular.

== Installation ==

1. Upload vamtam-love-it to wp-content/plugins
2. Click "Activate" in the WordPress plugins menu
3. A "Love It" link will be automatically added to the bottom of all posts / pages
4. Love It links are displayed to logged-in users only.

== Changelog ==

= 1.0 =

This is the first release, based on version 1.0.3 of the original plugin